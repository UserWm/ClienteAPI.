﻿namespace ClienteApiFull.Models
{
  
        public class LibroGet
        {
            public bool Confirmar { get; set; }
            public string Mensaje { get; set; }
            public object Errors { get; set; }
            public Libro Datos { get; set; }
        }
        public class LibroDatos
        {
            public int Id { get; set; }

            public string TituloLibro { get; set; }
            public int CantidadPaginas { get; set; }
            public string Editorial { get; set; }
            public int Cantidad { get; set; }
        }
    
}
