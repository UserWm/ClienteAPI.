﻿using ClienteApiFull.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace ClienteApiFull.Controllers
{
    public class HomeController : Controller
    {
        private readonly HttpClient _httpClient;

        public HomeController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("RestFullAPIBiblioteca");
        }
        public async Task<IActionResult> Index(int? page)
        {
            int pageNumber = page ?? 1;
            int pageSize = 2;
            var respons = await _httpClient.GetAsync("/api/v1/Libro");
            if (respons.IsSuccessStatusCode)
            {
                var json = await respons.Content.ReadAsStringAsync();
                var libros = JsonConvert.DeserializeObject<RespuestaApi>(json);

                // Calcular el total de registros
                int totalRegistros = libros.Datos.Count;

            var response = await _httpClient.GetAsync($"/api/v1/Libro?NumeroPagina={pageNumber}&TamanioPagina={pageSize}");
            if (response.IsSuccessStatusCode)
            {
                var jsn = await response.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<RespuestaApi>(jsn);

               
                    data.Total = totalRegistros;
                    return View(data);
                }

            }
            return View();
        }

    

        public IActionResult Agregar()
        {
            return View();
        }
 
		[HttpPost]
		public async Task<IActionResult> Crear(Libro libro)
		{
			if (ModelState.IsValid)
			{
				var json = JsonConvert.SerializeObject(libro);
				var content = new StringContent(json, Encoding.UTF8, "application/json");
				var response = await _httpClient.PostAsync("https://localhost:44356/api/v1/Libro", content);
				response.EnsureSuccessStatusCode();
				return RedirectToAction(nameof(Index));
			}
			return View(libro);
		}

        [HttpGet]
        public async Task<IActionResult> Modificar(int id)
        {
            var response = await _httpClient.GetAsync($"/api/v1/Libro/{id}");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var libroGet = JsonConvert.DeserializeObject<LibroGet>(json);
                var libro = new Libro
                {
                    Id = libroGet.Datos.Id,
                    TituloLibro = libroGet.Datos.TituloLibro,
                    CantidadPaginas = libroGet.Datos.CantidadPaginas,
                    Editorial = libroGet.Datos.Editorial,
                    Cantidad = libroGet.Datos.Cantidad
                };

                return View(libro);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Actualizar(Libro libro)
        {
            if (ModelState.IsValid)
            {
                var json = JsonConvert.SerializeObject(libro);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"https://localhost:44356/api/v1/Libro/{libro.Id}", content);
                response.EnsureSuccessStatusCode();
                return RedirectToAction(nameof(Index));
            }

            return View(libro);
        }

        public async Task<IActionResult> Eliminar(int id)
        {
            var response = await _httpClient.DeleteAsync($"/api/v1/Libro/{id}");
            response.EnsureSuccessStatusCode();
            return RedirectToAction(nameof(Index));
        }

    }


}
